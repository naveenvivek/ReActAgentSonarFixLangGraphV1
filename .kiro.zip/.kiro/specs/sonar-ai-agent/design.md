# Design Document

## Overview

The SonarQube AI Agent system implements a two-agent architecture using LangGraph workflows to automate code quality issue resolution. The Bug Hunter Agent connects to SonarQube, analyzes issues, and creates fix plans. The Code Healer Agent receives these plans, generates code fixes, and creates merge requests. All operations use local Ollama LLMs and are tracked through Langfuse for observability.

## Target Application Setup

The SonarQube AI Agent system is designed to work with any target application repository. The system will:

1. **Clone Target Repository**: Download the target application code locally for analysis
2. **SonarQube Integration**: The target application must be configured in SonarQube with a project key
3. **Repository Access**: The system needs read/write access to create branches and merge requests
4. **Supported Languages**: Works with any programming language supported by both SonarQube and Ollama models

### Target Application Configuration

```yaml
# Target Application: Spring Boot Application
target_application:
  name: "SpringBootAppSonarAI"
  repository: "https://github.com/naveenvivek/SpringBootAppSonarAI"
  sonar_project_key: "SpringBootAppSonarAI"
  primary_language: "Java"
  framework: "Spring Boot"
  build_tool: "Maven/Gradle"
```

**Repository Details**:
- **URL**: https://github.com/naveenvivek/SpringBootAppSonarAI
- **Language**: Java (Spring Boot application)
- **Purpose**: Target application for SonarQube analysis and AI-powered fixes
- **Access**: Public repository for cloning and creating pull requests

## Architecture

### High-Level Architecture

```mermaid
graph TD
    A[SonarQube Server<br/>localhost:9000<br/>Project: target-app] --> B[Bug Hunter Agent]
    B --> C[LangGraph Workflow]
    C --> D[Code Healer Agent]
    D --> E[Target Application<br/>Git Repository<br/>Merge Requests]
    
    F[Ollama LLM<br/>localhost:11434] --> B
    F --> D
    
    G[Langfuse Service<br/>localhost:3000] --> B
    G --> D
    
    H[Target App Clone<br/>./target-application] --> B
    H --> D
    
    I[Configuration<br/>target_repo_url<br/>sonar_project_key] --> B
    I --> D
```

### Agent Workflow

```mermaid
stateDiagram-v2
    [*] --> ConnectSonar : Bug Hunter Agent
    ConnectSonar --> FetchIssues
    FetchIssues --> AnalyzeIssues
    AnalyzeIssues --> CreateFixPlan
    CreateFixPlan --> HandoffToHealer : Pass Fix Plan
    
    HandoffToHealer --> ReceiveFixPlan : Code Healer Agent
    ReceiveFixPlan --> GenerateFixes
    GenerateFixes --> ValidateFixes
    ValidateFixes --> CreateMR
    CreateMR --> [*]
    
    AnalyzeIssues --> MoreIssues
    MoreIssues --> AnalyzeIssues : Yes
    MoreIssues --> CreateFixPlan : No
    
    ValidateFixes --> Valid
    Valid --> CreateMR : Pass
    Valid --> GenerateFixes : Fail
```

## Components and Interfaces

### 1. Bug Hunter Agent

**Purpose**: Connect to SonarQube, fetch issues from target application, analyze problems, create fix plans

**Key Methods**:
- `connect_to_sonar()`: Establish SonarQube connection
- `clone_target_repo()`: Clone the target application repository locally
- `fetch_issues(project_key)`: Retrieve issues for the target application from SonarQube
- `read_source_code(file_path, line_number)`: Read relevant code context from target application
- `analyze_issue(issue, code_context)`: Use Ollama LLM to understand problem context
- `create_fix_plan(issue, analysis)`: Generate solution strategy
- `prioritize_issues(issues)`: Sort by severity and impact

**Dependencies**:
- SonarQube API client
- Ollama LLM connection
- Langfuse observability

### 2. Code Healer Agent

**Purpose**: Receive fix plans, generate code fixes for target application, validate solutions, create merge requests

**Key Methods**:
- `receive_fix_plan(plan)`: Accept plan from Bug Hunter Agent
- `generate_code_fix(plan)`: Create actual code changes using Ollama LLM
- `apply_fix_to_file(file_path, fix)`: Apply generated fix to target application file
- `validate_fix(code_fix)`: Syntax and quality validation
- `create_git_branch(fix_name)`: Create feature branch in target application repo
- `commit_changes(branch, files)`: Commit fixes to branch
- `create_merge_request(branch, description)`: Submit MR to target application repository

**Dependencies**:
- Git repository access
- Ollama LLM connection
- Code validation tools
- Langfuse observability

### 3. LangGraph Workflow Manager

**Purpose**: Orchestrate agent communication and state management

**Key Components**:
- State management between agents
- Error handling and recovery
- Progress tracking
- Workflow visualization

### 4. MCP Integration Architecture

**Purpose**: Use official MCP servers for all external integrations

**Official MCP Servers Used**:

1. **GitHub MCP Server**: https://github.com/github/github-mcp-server
   - Handles GitHub API operations
   - Pull request creation
   - Repository management
   - File operations

2. **SonarQube MCP Server**: https://github.com/SonarSource/sonarqube-mcp-server  
   - SonarQube API integration
   - Issue fetching and analysis
   - Project metrics
   - Quality gate status

3. **Filesystem MCP Server**: Built-in MCP server
   - Local file operations
   - Directory management
   - File reading/writing

**MCP Configuration** (`.kiro/settings/mcp.json`):
```json
{
  "mcpServers": {
    "github": {
      "command": "uvx",
      "args": ["github/github-mcp-server@latest"],
      "env": {
        "GITHUB_TOKEN": "your_token_here"
      },
      "autoApprove": ["github_create_pull_request", "github_get_file_contents"]
    },
    "sonarqube": {
      "command": "uvx", 
      "args": ["SonarSource/sonarqube-mcp-server@latest"],
      "env": {
        "SONAR_URL": "http://localhost:9100",
        "SONAR_TOKEN": "your_token_here"
      },
      "autoApprove": ["sonar_get_issues", "sonar_get_project_status"]
    }
  }
}
```

### 5. Configuration Manager

**Purpose**: Minimal configuration - most settings handled via MCP server environment variables

**Configuration Class**:
```python
import os
from dataclasses import dataclass
from dotenv import load_dotenv

@dataclass
class Config:
    def __init__(self):
        # Load environment variables from .env file
        load_dotenv()
        
        # SonarQube Configuration
        self.sonar_url: str = os.getenv("SONAR_URL", "http://localhost:9000")
        self.sonar_token: str = os.getenv("SONAR_TOKEN")
        self.sonar_project_key: str = os.getenv("SONAR_PROJECT_KEY", "SpringBootAppSonarAI")
        
        # Target Application Repository
        self.target_repo_url: str = os.getenv("TARGET_REPO_URL")
        self.target_repo_path: str = os.getenv("TARGET_REPO_PATH")
        self.target_repo_branch: str = os.getenv("TARGET_REPO_BRANCH", "main")
        
        # AI Configuration
        self.ollama_url: str = os.getenv("OLLAMA_URL", "http://localhost:11434")
        self.ollama_model: str = os.getenv("OLLAMA_MODEL", "codellama:13b")
        
        # Observability
        self.langfuse_url: str = os.getenv("LANGFUSE_URL", "http://localhost:3000")
        self.langfuse_secret_key: str = os.getenv("LANGFUSE_SECRET_KEY")
        self.langfuse_public_key: str = os.getenv("LANGFUSE_PUBLIC_KEY")
        
        # Git Configuration
        self.git_user_name: str = os.getenv("GIT_USER_NAME", "SonarQube AI Agent")
        self.git_user_email: str = os.getenv("GIT_USER_EMAIL", "sonar-ai-agent@company.com")
        self.mr_target_branch: str = os.getenv("MR_TARGET_BRANCH", "main")
        
        # GitHub Configuration
        self.github_token: str = os.getenv("GITHUB_TOKEN")
        self.github_username: str = os.getenv("GITHUB_USERNAME")
        
        # Validate required environment variables
        self._validate_config()
    
    def _validate_config(self):
        required_vars = [
            ("SONAR_TOKEN", self.sonar_token),
            ("TARGET_REPO_URL", self.target_repo_url),
            ("TARGET_REPO_PATH", self.target_repo_path),
            ("LANGFUSE_SECRET_KEY", self.langfuse_secret_key),
            ("LANGFUSE_PUBLIC_KEY", self.langfuse_public_key),
            ("GITHUB_TOKEN", self.github_token)
        ]
        
        missing_vars = [var_name for var_name, var_value in required_vars if not var_value]
        
        if missing_vars:
            raise ValueError(f"Missing required environment variables: {', '.join(missing_vars)}")
```

**Your Actual .env Configuration**:
```bash
# .env file with your actual values
# SonarQube Configuration
SONAR_URL=http://localhost:9100
SONAR_TOKEN=squ_549d358adf050a6ff964616ab4f232812784c264
SONAR_PROJECT_KEY=naveenvivek_SpringBootAppSonarAI

# Target Application Repository  
TARGET_REPO_URL=https://github.com/naveenvivek/SpringBootAppSonarAI
TARGET_REPO_PATH=D:\Intellij\SpringBootAppSonarAI
TARGET_REPO_BRANCH=main

# AI Configuration
OLLAMA_URL=http://localhost:11434
OLLAMA_MODEL=llama3.1:latest

# Observability
LANGFUSE_URL=http://localhost:3000
LANGFUSE_SECRET_KEY=sk-lf-0f95895a-4d44-4afc-b54b-81f22786b786
LANGFUSE_PUBLIC_KEY=pk-lf-e6de0698-2862-438e-9138-30e92ed7b369

# Git Configuration
GIT_USER_NAME=SonarQube AI Agent
GIT_USER_EMAIL=50246903+naveenvivek@users.noreply.github.com
MR_TARGET_BRANCH=main

# GitHub Configuration
GITHUB_TOKEN=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
GITHUB_USERNAME=naveenvivek
```

**Template for Others (.env.example)**:
```bash
# .env.example (template file)
# Copy this to .env and fill in your actual values

# SonarQube Configuration
SONAR_URL=http://localhost:9000
SONAR_TOKEN=your_sonar_token_here
SONAR_PROJECT_KEY=SpringBootAppSonarAI

# Target Application Repository  
TARGET_REPO_URL=https://github.com/naveenvivek/SpringBootAppSonarAI
TARGET_REPO_PATH=D:\Intellij\SpringBootAppSonarAI
TARGET_REPO_BRANCH=main

# AI Configuration
OLLAMA_URL=http://localhost:11434
OLLAMA_MODEL=codellama:13b

# Observability
LANGFUSE_URL=http://localhost:3000
LANGFUSE_SECRET_KEY=sk-lf-your-secret-key-here
LANGFUSE_PUBLIC_KEY=pk-lf-your-public-key-here

# Git Configuration
GIT_USER_NAME=SonarQube AI Agent
GIT_USER_EMAIL=sonar-ai-agent@company.com
MR_TARGET_BRANCH=main

# GitHub Configuration
GITHUB_TOKEN=your_github_token_here
GITHUB_USERNAME=naveenvivek
```

## Data Models

### SonarQube Issue Model

```python
@dataclass
class SonarIssue:
    key: str
    rule: str
    severity: str  # BLOCKER, CRITICAL, MAJOR, MINOR, INFO
    component: str  # File path
    line: int
    message: str
    type: str  # BUG, VULNERABILITY, CODE_SMELL
    status: str
    creation_date: datetime
    tags: List[str]
```

### Fix Plan Model

```python
@dataclass
class FixPlan:
    issue_key: str
    issue_description: str
    file_path: str
    line_number: int
    problem_analysis: str
    proposed_solution: str
    code_context: str
    potential_side_effects: List[str]
    confidence_score: float
    estimated_effort: str
```

### Code Fix Model

```python
@dataclass
class CodeFix:
    fix_plan: FixPlan
    original_code: str
    fixed_code: str
    diff: str
    validation_status: bool
    validation_errors: List[str]
    branch_name: str
    commit_message: str
```

### Workflow State Model

```python
class WorkflowState(TypedDict):
    project_key: str
    sonar_issues: List[SonarIssue]
    current_issue_index: int
    fix_plans: List[FixPlan]
    code_fixes: List[CodeFix]
    merge_requests: List[str]
    errors: List[str]
    metadata: Dict[str, Any]
```

## Error Handling

### Connection Failures
- **SonarQube Unavailable**: Retry with exponential backoff, log to Langfuse
- **Ollama Unavailable**: Graceful degradation, queue requests for retry
- **Git Repository Issues**: Validate permissions, provide clear error messages

### Processing Errors
- **LLM Generation Failures**: Retry with different prompts, fallback strategies
- **Code Validation Failures**: Mark for manual review, continue with other issues
- **Merge Request Failures**: Log details, provide manual creation instructions

### State Recovery
- Persist workflow state at each major step
- Support resuming from last successful checkpoint
- Maintain audit trail of all operations

## Testing Strategy

### Unit Tests
- Individual agent method testing
- Mock SonarQube API responses
- Mock Ollama LLM responses
- Configuration validation

### Integration Tests
- End-to-end workflow testing
- SonarQube connection testing
- Git operations testing
- Langfuse logging verification

### Performance Tests
- Large issue set processing
- Memory usage monitoring
- Response time benchmarks
- Concurrent operation testing

### Quality Assurance
- Code fix accuracy validation
- Security vulnerability scanning
- Langfuse metric validation
- Error handling verification

## Security Considerations

### Local Processing
- All AI processing stays on localhost
- No external API calls for sensitive code
- Secure credential management

### Access Control
- SonarQube token-based authentication
- Git repository access validation
- Langfuse API key protection

### Code Safety
- Syntax validation before commits
- Backup creation before modifications
- Rollback capabilities for failed fixes

## Deployment Architecture

### Local Development Setup
```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   SonarQube     │    │     Ollama      │    │    Langfuse     │
│  localhost:9000 │    │ localhost:11434 │    │ localhost:3000  │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         └───────────────────────┼───────────────────────┘
                                 │
                    ┌─────────────────┐
                    │ SonarQube AI    │
                    │     Agent       │
                    │    System       │
                    └─────────────────┘
                                 │
                    ┌─────────────────┐
                    │ Target Git      │
                    │   Repository    │
                    └─────────────────┘
```

### Scalability Considerations
- Support for multiple concurrent repositories
- Batch processing for large issue sets
- Resource usage monitoring and limits
- Horizontal scaling for multiple projects

## Monitoring and Observability

### Langfuse Metrics
- Issue processing success rates
- Fix generation quality scores
- Processing time per issue
- Agent performance metrics
- Error frequency and types

### Logging Strategy
- Structured logging with correlation IDs
- Debug information for troubleshooting
- Performance metrics collection
- Security event logging

### Alerting
- Failed workflow notifications
- Quality score threshold alerts
- System resource warnings
- Integration failure alerts